import{j as o}from"./index-EjhmVW_V.js";import{P as t}from"./PolicyEmbed-BSjK0YOR.js";const p=()=>o.jsx(t,{id:"WVZoRlZFTmhSMDFaU0dWNVQwRTlQUT09",title:"Privacy Policy"});export{p as component};
