import{j as o}from"./index-CZgxEXR3.js";import{P as t}from"./PolicyEmbed-B4Zdlhlj.js";const p=()=>o.jsx(t,{id:"WVZoRlZFTmhSMDFaU0dWNVQwRTlQUT09",title:"Privacy Policy"});export{p as component};
