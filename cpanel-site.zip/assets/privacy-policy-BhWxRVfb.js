import{j as o}from"./index-Dino4hMy.js";import{P as t}from"./PolicyEmbed-CRAJtpSL.js";const p=()=>o.jsx(t,{id:"WVZoRlZFTmhSMDFaU0dWNVQwRTlQUT09",title:"Privacy Policy"});export{p as component};
