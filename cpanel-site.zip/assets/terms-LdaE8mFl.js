import{j as o}from"./index-Bd0vKgya.js";import{P as t}from"./PolicyEmbed-BsuYY0gx.js";const i=()=>o.jsx(t,{id:"UWtNdk4weEROMmhoUVd4WVRYYzlQUT09",title:"Terms of Service"});export{i as component};
