import{j as o}from"./index-CKkdICFw.js";import{P as t}from"./PolicyEmbed-C34vexQL.js";const i=()=>o.jsx(t,{id:"UWtNdk4weEROMmhoUVd4WVRYYzlQUT09",title:"Terms of Service"});export{i as component};
