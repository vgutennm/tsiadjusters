import{j as o}from"./index-CZgxEXR3.js";import{P as t}from"./PolicyEmbed-B4Zdlhlj.js";const i=()=>o.jsx(t,{id:"UWtNdk4weEROMmhoUVd4WVRYYzlQUT09",title:"Terms of Service"});export{i as component};
