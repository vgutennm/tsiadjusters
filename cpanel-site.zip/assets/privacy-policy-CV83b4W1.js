import{j as o}from"./index-Bd0vKgya.js";import{P as t}from"./PolicyEmbed-BsuYY0gx.js";const p=()=>o.jsx(t,{id:"WVZoRlZFTmhSMDFaU0dWNVQwRTlQUT09",title:"Privacy Policy"});export{p as component};
