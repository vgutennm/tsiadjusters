import{j as o}from"./index-CKkdICFw.js";import{P as t}from"./PolicyEmbed-C34vexQL.js";const p=()=>o.jsx(t,{id:"WVZoRlZFTmhSMDFaU0dWNVQwRTlQUT09",title:"Privacy Policy"});export{p as component};
