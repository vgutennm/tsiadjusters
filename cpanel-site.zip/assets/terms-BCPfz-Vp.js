import{j as o}from"./index-EjhmVW_V.js";import{P as t}from"./PolicyEmbed-BSjK0YOR.js";const i=()=>o.jsx(t,{id:"UWtNdk4weEROMmhoUVd4WVRYYzlQUT09",title:"Terms of Service"});export{i as component};
